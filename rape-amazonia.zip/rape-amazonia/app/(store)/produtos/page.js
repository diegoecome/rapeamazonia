import ProductCard from '@/components/ProductCard';
import { getProducts, getCategories } from '@/lib/queries';
import Link from 'next/link';

export const metadata = { title: 'Rapés — Rapé da Floresta' };

export default async function ProdutosPage({ searchParams }) {
  const categoriaSlug = searchParams?.categoria || null;

  const [products, categories] = await Promise.all([
    getProducts({ onlyActive: true }),
    getCategories(),
  ]);

  const filtered = categoriaSlug
    ? products.filter((p) => p.categories?.slug === categoriaSlug)
    : products;

  return (
    <section className="mx-auto max-w-6xl px-5 py-16">
      <div className="mb-10">
        <span className="font-mono text-xs uppercase tracking-[0.25em] text-gold-400">Catálogo</span>
        <h1 className="mt-2 font-display text-3xl text-sand-100 md:text-4xl">Rapés artesanais</h1>
      </div>

      {categories.length > 0 && (
        <div className="mb-8 flex flex-wrap gap-2">
          <Link
            href="/produtos"
            className={`focus-ring rounded-full border px-4 py-2 font-body text-sm transition-colors ${
              !categoriaSlug
                ? 'border-gold-400 text-gold-400'
                : 'border-white/15 text-sand-300/80 hover:border-gold-400'
            }`}
          >
            Todos
          </Link>
          {categories.map((c) => (
            <Link
              key={c.id}
              href={`/produtos?categoria=${c.slug}`}
              className={`focus-ring rounded-full border px-4 py-2 font-body text-sm transition-colors ${
                categoriaSlug === c.slug
                  ? 'border-gold-400 text-gold-400'
                  : 'border-white/15 text-sand-300/80 hover:border-gold-400'
              }`}
            >
              {c.name}
            </Link>
          ))}
        </div>
      )}

      {filtered.length === 0 ? (
        <p className="rounded-xl border border-dashed border-white/15 p-10 text-center font-body text-sand-300/60">
          Nenhum produto encontrado.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 md:gap-6">
          {filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </section>
  );
}
