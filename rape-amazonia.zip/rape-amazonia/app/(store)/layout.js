import { CartProvider } from '@/lib/cart-context';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import WhatsAppFloatButton from '@/components/WhatsAppFloatButton';
import { getStoreSettings } from '@/lib/queries';

export default async function StoreLayout({ children }) {
  const storeSettings = await getStoreSettings();
  const storeName = storeSettings?.store_info?.name;
  const whatsappNumber = storeSettings?.whatsapp?.number;

  return (
    <CartProvider>
      <Header storeName={storeName} />
      <main className="min-h-screen bg-forest-950">{children}</main>
      <Footer storeSettings={storeSettings} />
      <CartDrawer />
      <WhatsAppFloatButton number={whatsappNumber} />
    </CartProvider>
  );
}
