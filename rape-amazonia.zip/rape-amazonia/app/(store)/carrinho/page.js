'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useCart } from '@/lib/cart-context';
import { formatPrice } from '@/lib/format';
import { buildWhatsAppLink } from '@/lib/whatsapp';
import { createClient } from '@/lib/supabase/client';

export default function CarrinhoPage() {
  const { items, updateQty, removeItem, total, clearCart } = useCart();
  const [customer, setCustomer] = useState({ name: '', phone: '', address: '', notes: '' });
  const [whatsappNumber, setWhatsappNumber] = useState('');

  useEffect(() => {
    const supabase = createClient();
    supabase
      .from('store_settings')
      .select('value')
      .eq('key', 'whatsapp')
      .single()
      .then(({ data }) => {
        if (data?.value?.number) setWhatsappNumber(data.value.number);
      });
  }, []);

  const link = buildWhatsAppLink({ number: whatsappNumber, items, total, customer });

  if (items.length === 0) {
    return (
      <section className="mx-auto max-w-2xl px-5 py-24 text-center">
        <h1 className="font-display text-3xl text-sand-100">Seu carrinho está vazio</h1>
        <Link
          href="/produtos"
          className="focus-ring mt-8 inline-block rounded-full bg-gold-500 px-8 py-3 font-body text-sm font-medium text-forest-950 hover:bg-gold-400"
        >
          Ver rapés
        </Link>
      </section>
    );
  }

  return (
    <section className="mx-auto max-w-4xl px-5 py-16">
      <h1 className="font-display text-3xl text-sand-100 md:text-4xl">Finalizar pedido</h1>

      <div className="mt-10 grid gap-12 md:grid-cols-[1.2fr_1fr]">
        <div>
          <ul className="space-y-5">
            {items.map((item) => (
              <li key={item.id} className="flex items-center gap-4 border-b border-white/10 pb-5">
                <div className="h-20 w-20 shrink-0 overflow-hidden rounded-lg bg-wood-900">
                  {item.image && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="font-body text-sand-100">{item.name}</p>
                  <p className="mt-1 font-mono text-sm text-gold-400">{formatPrice(item.price)}</p>
                </div>
                <div className="flex items-center rounded-full border border-white/15">
                  <button
                    className="focus-ring px-3 py-1.5 text-sand-200"
                    onClick={() => updateQty(item.id, item.qty - 1)}
                  >
                    −
                  </button>
                  <span className="px-2 font-mono text-sm text-sand-100">{item.qty}</span>
                  <button
                    className="focus-ring px-3 py-1.5 text-sand-200"
                    onClick={() => updateQty(item.id, item.qty + 1)}
                  >
                    +
                  </button>
                </div>
                <button
                  onClick={() => removeItem(item.id)}
                  className="focus-ring font-body text-xs text-sand-300/50 hover:text-clay-500"
                >
                  remover
                </button>
              </li>
            ))}
          </ul>

          <div className="mt-6 flex items-center justify-between font-body text-lg">
            <span className="text-sand-300/70">Total</span>
            <span className="font-mono text-sand-100">{formatPrice(total)}</span>
          </div>
        </div>

        <form
          className="flex flex-col gap-4 rounded-2xl border border-white/10 bg-forest-900 p-6"
          onSubmit={(e) => e.preventDefault()}
        >
          <h2 className="font-display text-lg text-sand-100">Seus dados</h2>
          <p className="-mt-2 font-body text-xs text-sand-300/60">
            Usados apenas para montar sua mensagem de pedido no WhatsApp.
          </p>

          <label className="font-body text-sm text-sand-200">
            Nome
            <input
              className="focus-ring mt-1 w-full rounded-lg border border-white/15 bg-forest-950 px-3 py-2.5 text-sand-100"
              value={customer.name}
              onChange={(e) => setCustomer((c) => ({ ...c, name: e.target.value }))}
            />
          </label>

          <label className="font-body text-sm text-sand-200">
            Telefone
            <input
              className="focus-ring mt-1 w-full rounded-lg border border-white/15 bg-forest-950 px-3 py-2.5 text-sand-100"
              value={customer.phone}
              onChange={(e) => setCustomer((c) => ({ ...c, phone: e.target.value }))}
            />
          </label>

          <label className="font-body text-sm text-sand-200">
            Endereço
            <input
              className="focus-ring mt-1 w-full rounded-lg border border-white/15 bg-forest-950 px-3 py-2.5 text-sand-100"
              value={customer.address}
              onChange={(e) => setCustomer((c) => ({ ...c, address: e.target.value }))}
            />
          </label>

          <label className="font-body text-sm text-sand-200">
            Observações
            <textarea
              rows={3}
              className="focus-ring mt-1 w-full rounded-lg border border-white/15 bg-forest-950 px-3 py-2.5 text-sand-100"
              value={customer.notes}
              onChange={(e) => setCustomer((c) => ({ ...c, notes: e.target.value }))}
            />
          </label>

          <a
            href={link}
            target="_blank"
            rel="noreferrer"
            onClick={() => setTimeout(clearCart, 800)}
            className="focus-ring mt-2 rounded-full bg-gold-500 py-3.5 text-center font-body text-sm font-medium text-forest-950 transition-colors hover:bg-gold-400"
          >
            Finalizar pedido via WhatsApp
          </a>
        </form>
      </div>
    </section>
  );
}
