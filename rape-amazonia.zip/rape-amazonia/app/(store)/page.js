import Link from 'next/link';
import Hero from '@/components/Hero';
import ProductCard from '@/components/ProductCard';
import { getHomeContent, getProducts, getCategories } from '@/lib/queries';

export default async function HomePage() {
  const [content, products, categories] = await Promise.all([
    getHomeContent(),
    getProducts({ onlyActive: true }),
    getCategories(),
  ]);

  const featured = products.slice(0, 6);
  const manifesto = content?.manifesto || {};

  return (
    <>
      <Hero content={content} />

      {/* PRODUTOS EM DESTAQUE */}
      <section className="mx-auto max-w-6xl px-5 py-20">
        <div className="mb-10 flex items-end justify-between">
          <div>
            <span className="font-mono text-xs uppercase tracking-[0.25em] text-gold-400">
              Seleção
            </span>
            <h2 className="mt-2 font-display text-3xl text-sand-100">Rapés em destaque</h2>
          </div>
          <Link href="/produtos" className="focus-ring hidden font-body text-sm text-sand-300/70 hover:text-gold-400 md:block">
            Ver todos →
          </Link>
        </div>

        {featured.length === 0 ? (
          <p className="rounded-xl border border-dashed border-white/15 p-10 text-center font-body text-sand-300/60">
            Nenhum produto cadastrado ainda. Adicione produtos pelo painel administrativo.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 md:gap-6">
            {featured.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}

        <Link href="/produtos" className="focus-ring mt-8 block text-center font-body text-sm text-sand-300/70 hover:text-gold-400 md:hidden">
          Ver todos os rapés →
        </Link>
      </section>

      {/* CATEGORIAS */}
      {categories.length > 0 && (
        <section className="border-y border-white/10 bg-forest-900/50 px-5 py-16">
          <div className="mx-auto max-w-6xl">
            <span className="font-mono text-xs uppercase tracking-[0.25em] text-gold-400">
              Categorias
            </span>
            <div className="mt-6 flex flex-wrap gap-3">
              {categories.map((c) => (
                <Link
                  key={c.id}
                  href={`/produtos?categoria=${c.slug}`}
                  className="focus-ring rounded-full border border-white/15 px-5 py-2.5 font-body text-sm text-sand-200 transition-colors hover:border-gold-400 hover:text-gold-400"
                >
                  {c.name}
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ORIGEM */}
      <section id="origem" className="mx-auto max-w-4xl px-5 py-24 text-center">
        <span className="font-mono text-xs uppercase tracking-[0.25em] text-gold-400">Origem</span>
        <h2 className="mt-3 font-display text-3xl text-sand-100 md:text-4xl">
          Cada rapé tem uma origem real, não uma história inventada.
        </h2>
        <p className="mx-auto mt-5 max-w-2xl font-body leading-relaxed text-sand-300/80">
          Trabalhamos apenas com informações verificadas: região, comunidade produtora e processo
          declarados pelo próprio produtor. Você encontra esses dados na página de cada produto.
        </p>
      </section>

      {/* MANIFESTO */}
      <section id="historia" className="relative overflow-hidden bg-wood-900 px-5 py-24">
        <div className="grain-overlay opacity-[0.15]" />
        <div className="relative mx-auto max-w-3xl text-center">
          <h2 className="font-display text-3xl leading-snug text-sand-100 md:text-4xl">
            {manifesto.title || 'Não é um produto. É uma tradição que chega até você.'}
          </h2>
          <p className="mx-auto mt-5 max-w-xl font-body leading-relaxed text-sand-200/80">
            {manifesto.text ||
              'Cada rapé carrega o conhecimento de quem planta, colhe e prepara com as mãos.'}
          </p>
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="mx-auto max-w-6xl px-5 py-24 text-center">
        <h2 className="font-display text-2xl text-sand-100 md:text-3xl">Pronto para conhecer?</h2>
        <Link
          href="/produtos"
          className="focus-ring mt-8 inline-flex items-center gap-2 rounded-full bg-gold-500 px-8 py-3.5 font-body text-sm font-medium text-forest-950 transition-transform hover:scale-[1.03] hover:bg-gold-400"
        >
          Explorar rapés
        </Link>
      </section>
    </>
  );
}
