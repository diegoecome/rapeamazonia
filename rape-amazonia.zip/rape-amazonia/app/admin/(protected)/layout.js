import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import AdminSidebar from '@/components/admin/AdminSidebar';

export default async function ProtectedAdminLayout({ children }) {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect('/admin/login');

  const { data: adminRow } = await supabase
    .from('admin_users')
    .select('id')
    .eq('email', user.email)
    .maybeSingle();

  if (!adminRow) {
    await supabase.auth.signOut();
    redirect('/admin/login');
  }

  return (
    <div className="flex min-h-screen bg-neutral-950 text-white">
      <AdminSidebar email={user.email} />
      <div className="flex-1 overflow-y-auto p-8">{children}</div>
    </div>
  );
}
