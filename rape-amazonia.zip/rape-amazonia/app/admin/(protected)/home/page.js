import { createClient } from '@/lib/supabase/server';
import HomeContentForm from '@/components/admin/HomeContentForm';

export default async function AdminHomePage() {
  const supabase = createClient();
  const { data } = await supabase.from('home_content').select('key, value');

  const content = {};
  (data || []).forEach((row) => {
    content[row.key] = row.value;
  });

  return (
    <div>
      <h1 className="font-display text-2xl text-white">Página inicial</h1>
      <p className="mt-1 text-sm text-neutral-400">
        Edite os textos que aparecem na home da loja, sem precisar mexer em código.
      </p>

      <div className="mt-6">
        <HomeContentForm content={content} />
      </div>
    </div>
  );
}
