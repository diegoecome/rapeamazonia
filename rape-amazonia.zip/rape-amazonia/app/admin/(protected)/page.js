import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';

export default async function AdminDashboard() {
  const supabase = createClient();

  const [{ count: totalProducts }, { count: activeProducts }, { count: lowStock }] =
    await Promise.all([
      supabase.from('products').select('*', { count: 'exact', head: true }),
      supabase.from('products').select('*', { count: 'exact', head: true }).eq('status', 'active'),
      supabase.from('products').select('*', { count: 'exact', head: true }).lte('stock', 3),
    ]);

  const cards = [
    { label: 'Produtos cadastrados', value: totalProducts ?? 0 },
    { label: 'Produtos ativos na loja', value: activeProducts ?? 0 },
    { label: 'Com estoque baixo (≤3)', value: lowStock ?? 0 },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl text-white">Visão geral</h1>
      <p className="mt-1 text-sm text-neutral-400">Resumo rápido da sua loja.</p>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
        {cards.map((c) => (
          <div key={c.label} className="rounded-xl border border-white/10 bg-neutral-900 p-6">
            <p className="text-3xl font-semibold text-amber-400">{c.value}</p>
            <p className="mt-1 text-sm text-neutral-400">{c.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 flex flex-wrap gap-3">
        <Link
          href="/admin/produtos/novo"
          className="rounded-lg bg-amber-500 px-4 py-2.5 text-sm font-medium text-neutral-950 hover:bg-amber-400"
        >
          + Adicionar produto
        </Link>
        <Link
          href="/admin/home"
          className="rounded-lg border border-white/15 px-4 py-2.5 text-sm text-white hover:bg-white/5"
        >
          Editar página inicial
        </Link>
        <Link
          href="/admin/configuracoes"
          className="rounded-lg border border-white/15 px-4 py-2.5 text-sm text-white hover:bg-white/5"
        >
          Configurações da loja
        </Link>
      </div>
    </div>
  );
}
