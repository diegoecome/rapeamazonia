import Link from 'next/link';
import { createClient } from '@/lib/supabase/server';
import { formatPrice } from '@/lib/format';
import CategoryManager from '@/components/admin/CategoryManager';

export default async function AdminProductsPage() {
  const supabase = createClient();
  const [{ data: products }, { data: categories }] = await Promise.all([
    supabase
      .from('products')
      .select('*, product_images(url, is_main)')
      .order('created_at', { ascending: false }),
    supabase.from('categories').select('*').order('name'),
  ]);

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl text-white">Produtos</h1>
        <Link
          href="/admin/produtos/novo"
          className="rounded-lg bg-amber-500 px-4 py-2.5 text-sm font-medium text-neutral-950 hover:bg-amber-400"
        >
          + Adicionar produto
        </Link>
      </div>

      <div className="mt-6">
        <CategoryManager categories={categories || []} />
      </div>

      <div className="mt-6 overflow-hidden rounded-xl border border-white/10">
        <table className="w-full text-left text-sm">
          <thead className="bg-neutral-900 text-neutral-400">
            <tr>
              <th className="px-4 py-3 font-normal">Foto</th>
              <th className="px-4 py-3 font-normal">Nome</th>
              <th className="px-4 py-3 font-normal">Preço</th>
              <th className="px-4 py-3 font-normal">Estoque</th>
              <th className="px-4 py-3 font-normal">Status</th>
              <th className="px-4 py-3 font-normal" />
            </tr>
          </thead>
          <tbody>
            {(products || []).map((p) => {
              const main = (p.product_images || []).find((i) => i.is_main) || p.product_images?.[0];
              return (
                <tr key={p.id} className="border-t border-white/10 bg-neutral-950">
                  <td className="px-4 py-3">
                    <div className="h-10 w-10 overflow-hidden rounded bg-neutral-800">
                      {main?.url && (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={main.url} alt="" className="h-full w-full object-cover" />
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-white">{p.name}</td>
                  <td className="px-4 py-3 font-mono text-neutral-300">{formatPrice(p.promo_price || p.price)}</td>
                  <td className="px-4 py-3 text-neutral-300">{p.stock}</td>
                  <td className="px-4 py-3">
                    <span
                      className={`rounded-full px-2.5 py-1 text-xs ${
                        p.status === 'active'
                          ? 'bg-emerald-500/15 text-emerald-400'
                          : 'bg-neutral-700 text-neutral-400'
                      }`}
                    >
                      {p.status === 'active' ? 'Ativo' : 'Pausado'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Link href={`/admin/produtos/${p.id}`} className="text-amber-400 hover:underline">
                      Editar
                    </Link>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {(!products || products.length === 0) && (
          <p className="p-10 text-center text-neutral-500">Nenhum produto cadastrado ainda.</p>
        )}
      </div>
    </div>
  );
}
