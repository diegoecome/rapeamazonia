import { createClient } from '@/lib/supabase/server';
import ProductForm from '@/components/admin/ProductForm';

export default async function NovoProdutoPage() {
  const supabase = createClient();
  const { data: categories } = await supabase.from('categories').select('*').order('name');

  return (
    <div>
      <h1 className="font-display text-2xl text-white">Adicionar produto</h1>
      <p className="mt-1 text-sm text-neutral-400">
        Salve as informações básicas primeiro — as fotos podem ser adicionadas em seguida.
      </p>

      <div className="mt-6">
        <ProductForm product={null} images={[]} categories={categories || []} />
      </div>
    </div>
  );
}
