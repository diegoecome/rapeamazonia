import { createClient } from '@/lib/supabase/server';
import StoreSettingsForm from '@/components/admin/StoreSettingsForm';

export default async function AdminConfiguracoesPage() {
  const supabase = createClient();
  const { data } = await supabase.from('store_settings').select('key, value');

  const settings = {};
  (data || []).forEach((row) => {
    settings[row.key] = row.value;
  });

  return (
    <div>
      <h1 className="font-display text-2xl text-white">Configurações da loja</h1>
      <p className="mt-1 text-sm text-neutral-400">
        WhatsApp, dados da loja e informações de entrega.
      </p>

      <div className="mt-6">
        <StoreSettingsForm settings={settings} />
      </div>
    </div>
  );
}
