'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);

    const supabase = createClient();
    const { data, error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (signInError) {
      setError('E-mail ou senha incorretos.');
      setLoading(false);
      return;
    }

    // Confirma que este e-mail está na lista de administradores
    const { data: adminRow } = await supabase
      .from('admin_users')
      .select('id')
      .eq('email', data.user.email)
      .maybeSingle();

    if (!adminRow) {
      await supabase.auth.signOut();
      setError('Este e-mail não tem acesso ao painel administrativo.');
      setLoading(false);
      return;
    }

    router.push('/admin');
    router.refresh();
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-neutral-950 px-5">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm rounded-xl border border-white/10 bg-neutral-900 p-8"
      >
        <h1 className="font-display text-2xl text-white">Painel administrativo</h1>
        <p className="mt-1 text-sm text-neutral-400">Acesso restrito à equipe da loja.</p>

        <label className="mt-6 block text-sm text-neutral-300">
          E-mail
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 w-full rounded-lg border border-white/15 bg-neutral-950 px-3 py-2.5 text-white focus:border-amber-400 focus:outline-none"
          />
        </label>

        <label className="mt-4 block text-sm text-neutral-300">
          Senha
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 w-full rounded-lg border border-white/15 bg-neutral-950 px-3 py-2.5 text-white focus:border-amber-400 focus:outline-none"
          />
        </label>

        {error && <p className="mt-4 text-sm text-red-400">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="mt-6 w-full rounded-lg bg-amber-500 py-2.5 text-sm font-medium text-neutral-950 transition-colors hover:bg-amber-400 disabled:opacity-50"
        >
          {loading ? 'Entrando...' : 'Entrar'}
        </button>
      </form>
    </div>
  );
}
